Open the file Neant_fit.mlxtran in Monolix 2021R1.
It will internally load the data file Neant_data_normalised.csv, and the model file model_Neant.txt.
The initial conditions are set at the following values:
Population parameters: k3=1.6; k5=5; E0=0.00005; kp=4800; zeta=2.5;
For k1, the population parameter is fixed at 4.49 and the standard deviation is fixed at 0.28. All other values, including the error model parameters are same as the default.
The distributions of parameters k1, kp and zeta are set to logit distributions, and the following limits are set: k1: 2-7; kp: 10-5000; zeta:0-3;
Run and collect the results/plots.