Open the file Wolfel_sputum.mlxtran in Monolix 2021R1.
It will internally load the data file Wolfel_sputum_normalised.csv, and the model file model_Wolfel.txt.
The initial conditions are set at the following values:
Population parameters: k1= 5; k3=1; k5=1; E0=0.01; kp=4000; tao=5;
All other values, including the error model parameters, i.e., a=1; b=0.3 are same as the default.
The distributions of parameters k1, kp are set to logit distributions, and the following limits are set: k1: 2-7; kp: 10-5000; The rest of the parameters are fitted with the default lognormal distribution. Error model used is the default 'combined1'.
After the first run go to initial estimates section. Select 'All' under the option 'Use last estimates'. Now set the values of the population parameters and the error model parameters as listed above.
Run again (ignore the routine warning that running again will overwrite the results of the last session) and collect the results/plots.